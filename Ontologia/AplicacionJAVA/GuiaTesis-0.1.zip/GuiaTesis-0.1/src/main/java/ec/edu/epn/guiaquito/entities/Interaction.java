package ec.edu.epn.guiaquito.entities;

import javax.persistence.Embeddable;

@Embeddable
public class Interaction extends UserTracking {
}
